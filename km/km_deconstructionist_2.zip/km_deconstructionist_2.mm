<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#3366ff" CREATED="1129126390654" ID="Freemind_Link_1177678574" LINK="http://yyq123.journalspace.com/?entryid=116" MODIFIED="1129558250858" TEXT="&#x89e3;&#x6784;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#xff08;&#x4e2d;&#xff09;">
<edge COLOR="#808080" WIDTH="thin"/>
<font BOLD="true" NAME="sansserif" SIZE="18"/>
<node COLOR="#006699" CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_145666787" MODIFIED="1129557085264" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x6838;&#x5fc3;&#x6d41;&#x7a0b;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&lt;html&gt;&lt;img src=&quot;km_work_flow.png&quot;&gt;"/>
</node>
<node COLOR="#006699" CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_1250955852" MODIFIED="1129557086046" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7cfb;&#x7edf;&#x7684;7&#x4e2a;&#x5c42;&#x6b21;">
<node COLOR="#bfbfbf" CREATED="1129557894452" ID="_" MODIFIED="1129558040686" TEXT="&lt;html&gt;&lt;img src=&quot;km_syst_7layer.png&quot;&gt;">
<node CREATED="1124007973811" ID="Freemind_Link_1894704848" MODIFIED="1129558040718" TEXT="&#x4f7f;&#x7528;&#x754c;&#x9762; (Interface Layer) ">
<icon BUILTIN="full-1"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1542499999" MODIFIED="1129558040546" TEXT="&#x5b58;&#x53d6;&#x4e0e;&#x8ba4;&#x8bc1;&#x5c42; (Access &amp; Authentication Layer)">
<icon BUILTIN="full-2"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1052616513" MODIFIED="1129558040577" TEXT=" &#x534f;&#x540c;&#x4f5c;&#x4e1a;&#x4e0e;&#x4f01;&#x4e1a;&#x667a;&#x80fd;&#x5c42; (Collaborative &amp; Intelligence Layer)">
<icon BUILTIN="full-3"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1503795057" MODIFIED="1129558040608" TEXT="&#x5e94;&#x7528;&#x5c42; (Application Layer)">
<icon BUILTIN="full-4"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1041848292" MODIFIED="1129558040639" TEXT=" &#x4f20;&#x8f93;&#x5c42; (Transport Layer)">
<icon BUILTIN="full-5"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1965006012" MODIFIED="1129558040655" TEXT=" &#x4e2d;&#x4ecb;&#x8f6f;&#x4ef6;&#x4e0e;&#x7cfb;&#x7edf;&#x6574;&#x5408;&#x5c42; (Middleware &amp; Legacy Integration Layer) ">
<icon BUILTIN="full-6"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1546380805" MODIFIED="1129558132624" TEXT="&#x6570;&#x636e;&#x5e93; (Repository)  " VSHIFT="1">
<icon BUILTIN="full-7"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_1619560429" MODIFIED="1129557086796" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7cfb;&#x7edf;&#x7684;7&#x4e2a;&#x8981;&#x7d20;">
<node CREATED="1124007973811" ID="Freemind_Link_1937188211" MODIFIED="1129556984108" TEXT="&#x95e8;&#x6237;&#x6280;&#x672f;">
<icon BUILTIN="full-1"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_177676008" MODIFIED="1129556986374" TEXT="&#x641c;&#x7d22;&#x5f15;&#x64ce;&#x52a8;&#x6280;&#x672f;">
<icon BUILTIN="full-2"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_326930633" MODIFIED="1129556993030" TEXT="&#x534f;&#x4f5c;&#x6280;&#x672f;">
<icon BUILTIN="full-3"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_553922440" MODIFIED="1129556998999" TEXT="E-Learning&#x6280;&#x672f;">
<icon BUILTIN="full-4"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1699223234" MODIFIED="1129557001218" TEXT="&#x5546;&#x4e1a;&#x667a;&#x80fd;&#x6280;&#x672f;">
<icon BUILTIN="full-5"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1087857969" MODIFIED="1129557003561" TEXT="&#x5185;&#x5bb9;&#x7ba1;&#x7406;&#x6280;&#x672f;">
<icon BUILTIN="full-6"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_379449049" MODIFIED="1129557005468" TEXT="&#x96c6;&#x6210;&#x6280;&#x672f;">
<icon BUILTIN="full-7"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124007973811" ID="Freemind_Link_513875086" MODIFIED="1129557087405" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x4e3b;&#x8981;&#x6280;&#x672f;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&lt;html&gt;&lt;img src=&quot;km_syst_tech.png&quot;&gt;"/>
<node CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_628631299" MODIFIED="1129558201139" TEXT="&#x77e5;&#x8bc6;&#x5386;&#x7a0b;&#x56fe;">
<font NAME="sansserif" SIZE="12"/>
<icon BUILTIN="password"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5b9a;&#x4e49;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x77e5;&#x8bc6;&#x5386;&#x7a0b;&#x56fe;(Knowledge Storyboard)&#xff0c;&#x662f;&#x6307;&#x5728;&#x4f01;&#x4e1a;&#x7684;&#x4e1a;&#x52a1;&#x5faa;&#x73af;&#x4e2d;&#xff0c;&#x652f;&#x6301;&#x6d41;&#x7a0b;&#x6240;&#x9700;&#x7684;&#x77e5;&#x8bc6;&#x4ee5;&#x53ca;&#x53c2;&#x4e0e;&#x5176;&#x4e2d;&#x7684;&#x4eba;&#x7684;&#x56fe;&#x8868;&#x3002;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4f18;&#x52bf;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5c06;&#x4eba;&#x3001;&#x6d41;&#x7a0b;&#x548c;&#x77e5;&#x8bc6;&#x6709;&#x673a;&#x5730;&#x7ed3;&#x5408;&#x5728;&#x4e00;&#x8d77;"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_687528972" MODIFIED="1124007973811" TEXT="&#x6b65;&#x9aa4;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4e86;&#x89e3;&#x4e1a;&#x52a1;&#x6d41;&#x7a0b;&#x7684;&#x8fd0;&#x4f5c;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5206;&#x89e3;&#x4e1a;&#x52a1;&#x6d41;&#x7a0b;&#x7684;&#x5173;&#x952e;&#x4e8b;&#x4ef6;&#x70b9;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x627e;&#x51fa;&#x6bcf;&#x4e2a;&#x4e8b;&#x4ef6;&#x70b9;&#x7684;&#x76f8;&#x5173;&#x4eba;&#x5458;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x627e;&#x51fa;&#x6bcf;&#x4e2a;&#x4e8b;&#x4ef6;&#x70b9;&#x7684;&#x76f8;&#x5173;&#x77e5;&#x8bc6;"/>
</node>
</node>
<node CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_1405135764" MODIFIED="1129558198749" TEXT="&#x77e5;&#x8bc6;&#x7f51;&#x7edc;&#x56fe;">
<icon BUILTIN="password"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5b9a;&#x4e49;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x77e5;&#x8bc6;&#x7f51;&#x7edc;&#x56fe;(Knowledge Network)&#xff0c;&#x662f;&#x5c06;&#x77e5;&#x8bc6;&#x6309;&#x7167;&#x65b9;&#x4fbf;&#x4f7f;&#x7528;&#x548c;&#x7ba1;&#x7406;&#x7684;&#x539f;&#x5219;&#x8fdb;&#x884c;&#x5206;&#x7c7b;&#xff0c;&#x5efa;&#x7acb;&#x4e2d;&#x5fc3;&#x77e5;&#x8bc6;&#x548c;&#x56f4;&#x7ed5;&#x4e2d;&#x5fc3;&#x77e5;&#x8bc6;&#x7684;&#x536b;&#x661f;&#x77e5;&#x8bc6;&#x3002;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4f18;&#x52bf;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5c06;&#x6d41;&#x7a0b;&#x4e2d;&#x7684;&#x5404;&#x4e2a;&#x77e5;&#x8bc6;&#x70b9;&#x8054;&#x7cfb;&#x5728;&#x4e00;&#x8d77;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6b65;&#x9aa4;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x786e;&#x8ba4;&#x4e2d;&#x5fc3;&#x77e5;&#x8bc6;&#x5185;&#x5bb9;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5206;&#x89e3;&#x536b;&#x661f;&#x77e5;&#x8bc6;&#x5185;&#x5bb9;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4e3a;&#x6bcf;&#x4e2a;&#x536b;&#x661f;&#x77e5;&#x8bc6;&#x914d;&#x5907;&#x8d1f;&#x8d23;&#x4eba;"/>
</node>
</node>
<node CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_1288497841" MODIFIED="1129558195249" TEXT="&#x5bfc;&#x5e08;&#x5236;">
<icon BUILTIN="password"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5b9a;&#x4e49;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5bfc;&#x5e08;&#x5236;(Trainer-Trainee System, TTS)&#xff0c;&#x662f;&#x6307;&#x4e3a;&#x6bcf;&#x4e00;&#x4f4d;&#x65b0;&#x5458;&#x5de5;&#x6709;&#x9488;&#x5bf9;&#x6027;&#x5730;&#x6307;&#x5b9a;&#x4e00;&#x4f4d;&#x5bfc;&#x5e08;&#xff0c;&#x5bfc;&#x5e08;&#x901a;&#x8fc7;&#x6b63;&#x5f0f;&#x4e0e;&#x975e;&#x6b63;&#x5f0f;&#x7684;&#x9014;&#x5f84;&#x5c06;&#x81ea;&#x5df1;&#x7684;&#x77e5;&#x8bc6;&#x4f20;&#x6388;&#x7ed9;&#x65b0;&#x5458;&#x5de5;&#xff0c;&#x4f7f;&#x65b0;&#x5458;&#x5de5;&#x80fd;&#x591f;&#x5728;&#x65b0;&#x7684;&#x5de5;&#x4f5c;&#x5c97;&#x4f4d;&#x4e0a;&#x66f4;&#x597d;&#x7684;&#x9002;&#x5e94;&#x548c;&#x53d1;&#x5c55;&#x3002;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4f18;&#x52bf;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4e3a;&#x4f01;&#x4e1a;&#x63d0;&#x4f9b;&#x4eba;&#x624d;&#x4fdd;&#x969c;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x589e;&#x52a0;&#x540c;&#x4e8b;&#x4eb2;&#x548c;&#x529b;&#x548c;&#x56e2;&#x961f;&#x51dd;&#x805a;&#x529b;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6709;&#x52a9;&#x4e8e;&#x9690;&#x5f62;&#x77e5;&#x8bc6;&#x8f6c;&#x5316;&#x4e3a;&#x663e;&#x6027;&#x77e5;&#x8bc6;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6b65;&#x9aa4;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x786e;&#x5b9a;&#x5bfc;&#x5e08;&#x548c;&#x88ab;&#x57f9;&#x517b;&#x5bf9;&#x8c61;&#x7684;&#x8d44;&#x683c;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x786e;&#x5b9a;&#x57f9;&#x517b;&#x65b9;&#x5411;&#x3001;&#x65b9;&#x6cd5;&#x3001;&#x5185;&#x5bb9;&#x548c;&#x8bfe;&#x9898;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x8003;&#x6838;&#x548c;&#x4f18;&#x5316;"/>
</node>
</node>
<node CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_224150437" MODIFIED="1129558185483" TEXT="&#x5b9e;&#x8df5;&#x793e;&#x56e2;">
<icon BUILTIN="password"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5b9a;&#x4e49;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5b9e;&#x8df5;&#x793e;&#x56e2;(Community of Parctice, Cop)&#xff0c;&#x662f;&#x6307;&#x4e3a;&#x5206;&#x4eab;&#x77e5;&#x8bc6;&#x548c;&#x60c5;&#x611f;&#x6240;&#x7ec4;&#x6210;&#x7684;&#x975e;&#x6b63;&#x5f0f;&#x56e2;&#x4f53;&#x3002;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4f18;&#x52bf;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6709;&#x5229;&#x4e8e;&#x60c5;&#x611f;&#x7684;&#x4ea4;&#x6d41;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6709;&#x5229;&#x53d1;&#x6398;&#x4e2a;&#x4eba;&#x7684;&#x9690;&#x6027;&#x77e5;&#x8bc6;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6709;&#x5229;&#x4e8e;&#x77e5;&#x8bc6;&#x7684;&#x5171;&#x4eab;&#x548c;&#x521b;&#x65b0;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6709;&#x5229;&#x4e8e;&#x63d0;&#x5347;&#x51dd;&#x805a;&#x529b;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6709;&#x5229;&#x4e8e;&#x53d1;&#x73b0;&#x548c;&#x5438;&#x5f15;&#x4eba;&#x624d;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6b65;&#x9aa4;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x660e;&#x786e;&#x793e;&#x56e2;&#x5173;&#x6ce8;&#x7684;&#x9886;&#x57df;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x660e;&#x786e;&#x793e;&#x56e2;&#x7684;&#x6838;&#x5fc3;&#x4ef7;&#x503c;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x9009;&#x62e9;&#x793e;&#x56e2;&#x4fc3;&#x8fdb;&#x8005;&#x534f;&#x8c03;&#x793e;&#x56e2;&#x7684;&#x6d3b;&#x52a8;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5438;&#x5f15;&#x6210;&#x5458;&#x52a0;&#x5165;&#x793e;&#x56e2;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x901a;&#x8fc7;&#x5b9e;&#x8df5;&#x5206;&#x4eab;&#x77e5;&#x8bc6;"/>
</node>
</node>
<node CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_1703618875" MODIFIED="1129558183546" TEXT="&#x4e8b;&#x540e;&#x603b;&#x7ed3;">
<icon BUILTIN="password"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5b9a;&#x4e49;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4e8b;&#x540e;&#x603b;&#x7ed3;(After Action Reviews, AAR)&#xff0c;&#x662f;&#x6307;&#x901a;&#x8fc7;&#x603b;&#x7ed3;&#x8fc7;&#x53bb;&#x6210;&#x529f;&#x548c;&#x5931;&#x8d25;&#x7684;&#x7ecf;&#x9a8c;&#x6559;&#x8bad;&#xff0c;&#x6539;&#x8fdb;&#x672a;&#x6765;&#x7684;&#x8868;&#x73b0;&#x3002;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4f18;&#x52bf;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6709;&#x5229;&#x4e8e;&#x83b7;&#x53d6;&#x9690;&#x6027;&#x77e5;&#x8bc6;&#x5e76;&#x5c06;&#x5176;&#x8f6c;&#x5316;&#x4e3a;&#x663e;&#x6027;&#x77e5;&#x8bc6;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6709;&#x5229;&#x4e8e;&#x8bca;&#x65ad;&#x548c;&#x8bc4;&#x4f30;&#x4e2a;&#x4eba;&#x53ca;&#x56e2;&#x961f;&#x7684;&#x8868;&#x73b0;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6709;&#x5229;&#x4e8e;&#x63d0;&#x9ad8;&#x53d1;&#x73b0;&#x548c;&#x603b;&#x7ed3;&#x77e5;&#x8bc6;&#x7684;&#x80fd;&#x529b;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6709;&#x5229;&#x4e8e;&#x57f9;&#x517b;&#x56e2;&#x961f;&#x7684;&#x5b66;&#x4e60;&#x7cbe;&#x795e;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6b65;&#x9aa4;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x53ca;&#x65f6;&#x5730;&#x53ec;&#x5f00;&#x603b;&#x7ed3;&#x4f1a;&#x8bae;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x8425;&#x9020;&#x826f;&#x597d;&#x7684;&#x8ba8;&#x8bba;&#x6c1b;&#x56f4;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6307;&#x5b9a;&#x4e00;&#x4e2a;&#x63a8;&#x52a8;&#x8005;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x91cd;&#x65b0;&#x5ba1;&#x89c6;&#x9879;&#x76ee;&#x76ee;&#x6807;&#x548c;&#x4ea4;&#x4ed8;&#x7269;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5bfb;&#x627e;&#x9879;&#x76ee;&#x6210;&#x529f;&#x6216;&#x5931;&#x8d25;&#x7684;&#x539f;&#x56e0;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x786e;&#x4fdd;&#x6240;&#x6709;&#x53c2;&#x4e0e;&#x4f1a;&#x8bae;&#x8005;&#x90fd;&#x5145;&#x5206;&#x53d1;&#x8868;&#x4e86;&#x81ea;&#x5df1;&#x7684;&#x610f;&#x89c1;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x603b;&#x7ed3;&#x6539;&#x8fdb;&#x7684;&#x63aa;&#x65bd;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x8bb0;&#x5f55;&#x4e8b;&#x540e;&#x603b;&#x7ed3;&#x4f1a;&#x8bae;&#x7684;&#x5185;&#x5bb9;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5206;&#x4eab;&#x4ece;&#x4e8b;&#x540e;&#x603b;&#x7ed3;&#x4f1a;&#x8bae;&#x4e2d;&#x83b7;&#x5f97;&#x7684;&#x77e5;&#x8bc6;"/>
</node>
</node>
<node CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_297148897" MODIFIED="1129558181827" TEXT="&#x4f01;&#x4e1a;&#x4fe1;&#x606f;&#x95e8;&#x6237;">
<icon BUILTIN="password"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5b9a;&#x4e49;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4f01;&#x4e1a;&#x4fe1;&#x606f;&#x95e8;&#x6237;(Enterprise Information Portal, EIP)&#xff0c;&#x662f;&#x6307;&#x5c06;&#x4f01;&#x4e1a;&#x7684;&#x6240;&#x6709;&#x5e94;&#x7528;&#x548c;&#x6570;&#x636e;&#x96c6;&#x6210;&#x5230;&#x4e00;&#x4e2a;&#x4fe1;&#x606f;&#x7ba1;&#x7406;&#x5e73;&#x53f0;&#x4e4b;&#x4e0a;&#xff0c;&#x5e76;&#x4ee5;&#x7edf;&#x4e00;&#x7684;&#x7528;&#x6237;&#x754c;&#x9762;&#x63d0;&#x4f9b;&#x7ed9;&#x7528;&#x6237;&#xff0c;&#x4f7f;&#x4f01;&#x4e1a;&#x53ef;&#x4ee5;&#x5feb;&#x901f;&#x5730;&#x5efa;&#x7acb;&#x4f01;&#x4e1a;&#x5bf9;&#x4f01;&#x4e1a;&#x548c;&#x4f01;&#x4e1a;&#x5bf9;&#x5185;&#x90e8;&#x5458;&#x5de5;&#x7684;&#x4fe1;&#x606f;&#x95e8;&#x6237;&#x3002;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4f18;&#x52bf;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x63d0;&#x4f9b;&#x7edf;&#x4e00;&#x7684;&#x4fe1;&#x606f;&#x8bbf;&#x95ee;&#x6e20;&#x9053;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x63d0;&#x4f9b;&#x4e0d;&#x95f4;&#x65ad;&#x7684;&#x670d;&#x52a1;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x63d0;&#x4f9b;&#x5f3a;&#x5927;&#x7684;&#x5185;&#x5bb9;&#x7ba1;&#x7406;&#x80fd;&#x529b;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x63d0;&#x4f9b;&#x4e2a;&#x6027;&#x5316;&#x7684;&#x5e94;&#x7528;&#x670d;&#x52a1;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x63d0;&#x4f9b;&#x534f;&#x4f5c;&#x5de5;&#x4f5c;&#x7684;&#x5e73;&#x53f0;"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6b65;&#x9aa4;&#xff1a;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="EIP&#x7684;&#x89c4;&#x5212;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="EIP&#x4ea7;&#x54c1;&#x548c;&#x4f9b;&#x5e94;&#x5546;&#x7684;&#x9009;&#x62e9;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="EIP&#x7684;&#x5b9e;&#x65bd;"/>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="EIP&#x7684;&#x6301;&#x7eed;&#x6539;&#x8fdb;"/>
</node>
</node>
<node CREATED="1127660286890" FOLDED="true" ID="Freemind_Link_992460594" MODIFIED="1129558180108" TEXT="&#x4f01;&#x4e1a;Blog">
<icon BUILTIN="password"/>
<node CREATED="1127660314999" ID="Freemind_Link_302393726" MODIFIED="1129557143311" TEXT="&#x5b9a;&#x4e49;&#xff1a;">
<node CREATED="1127660319562" ID="Freemind_Link_1013636194" MODIFIED="1129557356124" TEXT="&#x4f01;&#x4e1a;Blog&#xff08;Corporate Blogging&#xff09;&#xff0c;&#x662f;&#x4f01;&#x4e1a;&#x521b;&#x5efa;&#x548c;&#x7ef4;&#x62a4;&#x7684;Blog&#x7cfb;&#x7edf;&#x3002;&#x65e2;&#x53ef;&#x4ee5;&#x662f;&#x9762;&#x5411;&#x5185;&#x90e8;&#x7684;&#xff0c;&#x4e5f;&#x53ef;&#x4ee5;&#x662f;&#x9762;&#x5411;&#x5916;&#x90e8;&#x7684;&#x3002;&#x7531;&#x4e8e;&#x64cd;&#x4f5c;&#x7b80;&#x4fbf;&#xff0c;&#x7528;&#x6237;&#x53c2;&#x4e0e;&#x5ea6;&#x9ad8;&#xff0c;&#x53ef;&#x4ee5;&#x7528;&#x4e8e;&#x77e5;&#x8bc6;&#x5206;&#x4eab;&#x548c;&#x6c9f;&#x901a;&#x4ea4;&#x6d41;&#x3002;"/>
</node>
<node CREATED="1127660394952" ID="Freemind_Link_1962595610" MODIFIED="1129557146780" TEXT="&#x4f18;&#x52bf;&#xff1a;">
<node CREATED="1127660677937" ID="Freemind_Link_83661935" MODIFIED="1129557437655" TEXT="&#x4f7f;&#x7528;&#x65b9;&#x4fbf;"/>
<node CREATED="1127660398359" ID="Freemind_Link_1250284864" MODIFIED="1127660433374" TEXT="&#x53ef;&#x4ee5;&#x5feb;&#x901f;&#x7684;&#x53d1;&#x5e03;&#x4fe1;&#x606f;"/>
<node CREATED="1127660690546" ID="Freemind_Link_639426196" MODIFIED="1127660912640" TEXT="&#x4f7f;&#x7528;&#x57fa;&#x4e8e;&#x4f1a;&#x8bdd;&#x548c;&#x4e3b;&#x9898;&#x7684;&#x4ea4;&#x6d41;&#x65b9;&#x5f0f;"/>
<node CREATED="1127660486499" ID="Freemind_Link_1745686355" MODIFIED="1127660540249" TEXT="&#x53ef;&#x4ee5;&#x53ca;&#x65f6;&#x5730;&#x83b7;&#x5f97;&#x53cd;&#x9988;&#x548c;&#x5efa;&#x8bae;"/>
<node CREATED="1127661455796" ID="Freemind_Link_885501610" MODIFIED="1127661467249" TEXT="&#x80fd;&#x591f;&#x63d0;&#x9ad8;&#x5ba2;&#x6237;&#x6ee1;&#x610f;&#x5ea6;"/>
</node>
<node CREATED="1127660915781" ID="Freemind_Link_20683119" MODIFIED="1129557148718" TEXT="&#x5b9e;&#x65bd;&#x6b65;&#x9aa4;&#xff1a;">
<node CREATED="1127660926015" ID="Freemind_Link_1584546616" MODIFIED="1127660944531" TEXT="&#x521b;&#x5efa;&#x516c;&#x5f00;&#x548c;&#x900f;&#x660e;&#x7684;&#x4f01;&#x4e1a;&#x6587;&#x5316;"/>
<node CREATED="1127660945484" ID="Freemind_Link_231568646" MODIFIED="1127660962921" TEXT="&#x90e8;&#x7f72;Blog&#x7cfb;&#x7edf;"/>
<node CREATED="1127660964031" ID="Freemind_Link_773877316" MODIFIED="1129557557718" TEXT="&#x79ef;&#x6781;&#x56de;&#x5e94;&#x4ece;Blog&#x53cd;&#x9988;&#x7684;&#x4fe1;&#x606f;"/>
<node CREATED="1127661028906" ID="Freemind_Link_1810675975" MODIFIED="1127661105093" TEXT="&#x521b;&#x5efa;&#x9f13;&#x52b1;Blog&#x7684;&#x6fc0;&#x52b1;&#x5236;&#x5ea6;"/>
<node CREATED="1127661107812" ID="Freemind_Link_1197629922" MODIFIED="1127661387374" TEXT="&#x5c06;Blog&#x53d8;&#x6210;&#x65e5;&#x5e38;&#x5de5;&#x4f5c;&#x7684;&#x7ec4;&#x6210;&#x90e8;&#x5206;"/>
</node>
</node>
<node CREATED="1124288434464" FOLDED="true" ID="Freemind_Link_179571750" MODIFIED="1129558165624" TEXT="&#x4e13;&#x5bb6;&#x9ec4;&#x9875;">
<icon BUILTIN="password"/>
<node CREATED="1124371145498" ID="Freemind_Link_1756790034" MODIFIED="1129557678858" TEXT="&#x5b9a;&#x4e49;&#xff1a;">
<node CREATED="1124371204123" ID="Freemind_Link_8418339" MODIFIED="1127660275171" TEXT="&#x4e13;&#x5bb6;&#x9ec4;&#x9875;&#xff08;Experts Yellow Page&#xff09;&#xff0c;&#x662f;&#x5c06;&#x4e13;&#x5bb6;&#x7684;&#x8be6;&#x7ec6;&#x8d44;&#x6599;&#x548c;&#x638c;&#x63e1;&#x7684;&#x77e5;&#x8bc6;&#x5217;&#x793a;&#x5728;&#x9ec4;&#x9875;&#x4e0a;&#xff0c;&#x65b9;&#x4fbf;&#x6709;&#x9700;&#x8981;&#x7684;&#x5458;&#x5de5;&#x5728;&#x9002;&#x5f53;&#x7684;&#x65f6;&#x95f4;&#x627e;&#x5230;&#x9002;&#x5f53;&#x7684;&#x4eba;&#x5e76;&#x83b7;&#x5f97;&#x9002;&#x5f53;&#x7684;&#x77e5;&#x8bc6;&#x3002;"/>
</node>
<node CREATED="1124371419436" ID="Freemind_Link_1177912033" MODIFIED="1129557699014" TEXT="&#x4f18;&#x52bf;&#xff1a;">
<node CREATED="1124371423092" ID="Freemind_Link_551683779" MODIFIED="1124371444967" TEXT="&#x53ef;&#x4ee5;&#x52a0;&#x5f3a;&#x5458;&#x5de5;&#x95f4;&#x7684;&#x6c9f;&#x901a;&#x4e0e;&#x5408;&#x4f5c;"/>
<node CREATED="1124371815264" ID="Freemind_Link_608414629" MODIFIED="1124371833717" TEXT="&#x53d1;&#x73b0;&#x548c;&#x5145;&#x5206;&#x5229;&#x7528;&#x5458;&#x5de5;&#x7684;&#x77e5;&#x8bc6;"/>
<node CREATED="1124371930951" ID="Freemind_Link_300974474" MODIFIED="1124371945514" TEXT="&#x589e;&#x5f3a;&#x5458;&#x5de5;&#x7684;&#x6210;&#x5c31;&#x611f;"/>
</node>
<node CREATED="1124371472545" ID="Freemind_Link_710125358" MODIFIED="1129558156186" TEXT="&#x5b9e;&#x65bd;&#x6b65;&#x9aa4;&#xff1a;">
<node CREATED="1124371503342" ID="Freemind_Link_835384677" MODIFIED="1124371515857" TEXT="&#x6536;&#x96c6;&#x5458;&#x5de5;&#x7684;&#x4fe1;&#x606f;"/>
<node CREATED="1124371568029" ID="Freemind_Link_499381081" MODIFIED="1127660183296" TEXT="&#x6309;&#x77e5;&#x8bc6;&#x9886;&#x57df;&#x5bf9;&#x5458;&#x5de5;&#x5206;&#x7c7b;&#x5e76;&#x8bc6;&#x522b;&#x51fa;&#x4e13;&#x5bb6;"/>
<node CREATED="1124371675717" ID="Freemind_Link_1407098064" MODIFIED="1129557826843" TEXT="&#x521b;&#x5efa;&#x5177;&#x6709;&#x5f3a;&#x5927;&#x5206;&#x7c7b;&#x548c;&#x641c;&#x7d22;&#x529f;&#x80fd;&#x7684;&#x9ec4;&#x9875;&#x7cfb;&#x7edf;"/>
<node CREATED="1124371854561" ID="Freemind_Link_1444490262" MODIFIED="1124371877029" TEXT="&#x63d0;&#x4f9b;&#x5229;&#x4e8e;&#x5408;&#x4f5c;&#x7684;&#x6280;&#x672f;&#x548c;&#x6d41;&#x7a0b;"/>
<node CREATED="1124372126154" ID="Freemind_Link_1722474322" MODIFIED="1124372161186" TEXT="&#x5bf9;&#x4e13;&#x5bb6;&#x8fdb;&#x884c;&#x8ba4;&#x8bc1;&#x548c;&#x6fc0;&#x52b1;"/>
</node>
</node>
</node>
</node>
</map>
