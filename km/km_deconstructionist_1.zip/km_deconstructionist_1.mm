<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#3366ff" CREATED="1128865582653" ID="Freemind_Link_617586214" MODIFIED="1128865753324" TEXT="&#x89e3;&#x6784;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#xff08;&#x4e0a;&#xff09;">
<edge COLOR="#808080" WIDTH="thin"/>
<font BOLD="true" NAME="SansSerif" SIZE="18"/>
<node COLOR="#006699" CREATED="1124007973795" FOLDED="true" ID="Freemind_Link_976049380" MODIFIED="1128865836043" POSITION="right" TEXT="&#x5f00;&#x7bc7;">
<node CREATED="1128865818653" MODIFIED="1128865818653" TEXT="&#x7ba1;&#x7406;&#x5927;&#x5e08;&#x5fb7;&#x9c81;&#x514b;&#x8ba4;&#x4e3a;&#xff1a;&#x201c;&#xff12;&#xff11;&#x4e16;&#x7eaa;&#x7684;&#x7ec4;&#x7ec7;&#xff0c;&#x6700;&#x6709;&#x4ef7;&#x503c;&#x7684;&#x8d44;&#x4ea7;&#x662f;&#x7ec4;&#x7ec7;&#x5185;&#x7684;&#x77e5;&#x8bc6;&#x5de5;&#x4f5c;&#x8005;&#x548c;&#x4ed6;&#x4eec;&#x7684;&#x751f;&#x4ea7;&#x529b;&#x3002;&#x201d;"/>
<node CREATED="1128865818653" MODIFIED="1128865818653" TEXT="&#x5728;&#x4fe1;&#x606f;&#x65f6;&#x4ee3;&#x91cc;&#xff0c;&#x77e5;&#x8bc6;&#x5df2;&#x6210;&#x4e3a;&#x6700;&#x4e3b;&#x8981;&#x7684;&#x8d22;&#x5bcc;&#x6765;&#x6e90;&#xff0c;&#x800c;&#x77e5;&#x8bc6;&#x5de5;&#x4f5c;&#x8005;&#x5c31;&#x662f;&#x6700;&#x6709;&#x751f;&#x547d;&#x529b;&#x7684;&#x8d44;&#x4ea7;&#xff0c;&#x7ec4;&#x7ec7;&#x548c;&#x4e2a;&#x4eba;&#x7684;&#x6700;&#x91cd;&#x8981;&#x4efb;&#x52a1;&#x5c31;&#x662f;&#x5bf9;&#x77e5;&#x8bc6;&#x8fdb;&#x884c;&#x7ba1;&#x7406;&#x3002;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x5c06;&#x4f7f;&#x7ec4;&#x7ec7;&#x548c;&#x4e2a;&#x4eba;&#x5177;&#x6709;&#x66f4;&#x5f3a;&#x7684;&#x7ade;&#x4e89;&#x5b9e;&#x529b;&#xff0c;&#x5e76;&#x505a;&#x51fa;&#x66f4;&#x597d;&#x5730;&#x51b3;&#x7b56;&#x3002;&#x5728;2000&#x5e74;&#x7684;&#x91cc;&#x65af;&#x672c;&#x6b27;&#x6d32;&#x7406;&#x4e8b;&#x4f1a;&#x4e0a;&#xff0c;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x66f4;&#x662f;&#x88ab;&#x4e0a;&#x5347;&#x5230;&#x6218;&#x7565;&#x7684;&#x5c42;&#x6b21;&#xff1a;&#x201c;&#x6b27;&#x6d32;&#x5c06;&#x7528;&#x66f4;&#x597d;&#x7684;&#x5de5;&#x4f5c;&#x548c;&#x793e;&#x4f1a;&#x51dd;&#x805a;&#x529b;&#x63a8;&#x52a8;&#x7ecf;&#x6d4e;&#x53d1;&#x5c55;&#xff0c;&#x5728;2010&#x5e74;&#x6210;&#x4e3a;&#x5168;&#x7403;&#x6700;&#x5177;&#x7ade;&#x4e89;&#x529b;&#x548c;&#x6700;&#x5177;&#x6d3b;&#x529b;&#x7684;&#x77e5;&#x8bc6;&#x7ecf;&#x6d4e;&#x5b9e;&#x4f53;&#x3002;&#x201d;"/>
<node CREATED="1128865818653" MODIFIED="1128865818653" TEXT="&#x5bf9;&#x4e8e;&#x7ec4;&#x7ec7;&#x548c;&#x4e2a;&#x4eba;&#xff0c;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#xff08;Knowledge management, KM&#xff09;&#x90fd;&#x5df2;&#x7ecf;&#x6210;&#x4e3a;&#x4f1f;&#x5927;&#x673a;&#x9047;&#x548c;&#x6311;&#x6218;&#x3002;"/>
</node>
<node COLOR="#006699" CREATED="1124007973795" ID="Freemind_Link_870862589" MODIFIED="1128865839262" POSITION="right" TEXT="&#x4ec0;&#x4e48;&#x662f;&#x77e5;&#x8bc6;">
<node CREATED="1124007973795" MODIFIED="1124007973795" TEXT="&#x77e5;&#x8bc6;&#x662f;&#x7528;&#x4e8e;&#x751f;&#x4ea7;&#x7684;&#x4fe1;&#x606f;&#xff08;&#x6709;&#x610f;&#x4e49;&#x7684;&#x4fe1;&#x606f;&#xff09;&#x3002;&#xa;&#xff0d;&#xff0d;1998&#x5e74;&#xff0c;&#x4e16;&#x754c;&#x94f6;&#x884c;&#x300a;1998&#x5e74;&#x4e16;&#x754c;&#x53d1;&#x5c55;&#x62a5;&#x544a;&#xff0d;&#x77e5;&#x8bc6;&#x4fc3;&#x8fdb;&#x53d1;&#x5c55;&#x300b;">
<cloud/>
</node>
</node>
<node COLOR="#006699" CREATED="1126015655671" FOLDED="true" ID="Freemind_Link_991378374" MODIFIED="1128865840231" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7684;&#x7279;&#x6027;">
<node CREATED="1126016385483" ID="Freemind_Link_1617431224" LINK="http://yyq123.journalspace.com/?entryid=8" MODIFIED="1128931860468" TEXT="&#x77e5;&#x8bc6;&#x5177;&#x6709;&#x4ee5;&#x4e0b;&#x56db;&#x4e2a;&#x7279;&#x6027;"/>
<node CREATED="1126015860514" ID="Freemind_Link_1161421141" MODIFIED="1126016362717" TEXT="&#x60ca;&#x4eba;&#x7684;&#x53ef;&#x6709;&#x591a;&#x6b21;&#x5229;&#x7528;&#x7387;&#x548c;&#x4e0d;&#x65ad;&#x4e0a;&#x5347;&#x7684;&#x56de;&#x62a5;&#x3002;">
<icon BUILTIN="full-1"/>
</node>
<node CREATED="1126015890421" ID="Freemind_Link_328259304" MODIFIED="1126016365171" TEXT="&#x6563;&#x4e71;&#x3001;&#x9057;&#x6f0f;&#x548c;&#x66f4;&#x65b0;&#x9700;&#x8981;&#x3002;">
<icon BUILTIN="full-2"/>
</node>
<node CREATED="1126015909655" ID="Freemind_Link_1383272513" MODIFIED="1126016370264" TEXT="&#x4e0d;&#x786e;&#x5b9a;&#x7684;&#x4ef7;&#x503c;&#x3002;">
<icon BUILTIN="full-3"/>
</node>
<node CREATED="1126015937530" ID="Freemind_Link_682297250" MODIFIED="1126016373077" TEXT="&#x4e0d;&#x786e;&#x5b9a;&#x7684;&#x5229;&#x76ca;&#x5206;&#x6210;&#x3002;">
<icon BUILTIN="full-4"/>
</node>
<node CREATED="1126016339124" MODIFIED="1126016339124" TEXT="Source: Jonathan D. Day,  James C.Wendler"/>
</node>
<node COLOR="#006699" CREATED="1124007973795" FOLDED="true" ID="Freemind_Link_140071395" MODIFIED="1128865840934" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7684;&#x5206;&#x7c7b;">
<node CREATED="1124007973795" FOLDED="true" ID="Freemind_Link_1623844198" MODIFIED="1124007973795" TEXT="&#x9690;&#x6027;&#x77e5;&#x8bc6; (Tacit Knowledge)">
<node CREATED="1124007973795" MODIFIED="1124007973795" TEXT="&#x662f;&#x9ad8;&#x5ea6;&#x4e2a;&#x6027;&#x5316;&#x800c;&#x4e14;&#x96be;&#x4e8e;&#x683c;&#x5f0f;&#x5316;&#x7684;&#x77e5;&#x8bc6;&#xff0c;&#x4e3b;&#x89c2;&#x7684;&#x7406;&#x89e3;&#x3001;&#x76f4;&#x89c9;&#x548c;&#x9884;&#x611f;&#x90fd;&#x5c5e;&#x4e8e;&#x8fd9;&#x4e00;&#x7c7b;&#x3002;"/>
</node>
<node CREATED="1124007973795" FOLDED="true" ID="Freemind_Link_1782294029" MODIFIED="1124007973795" TEXT="&#x663e;&#x6027;&#x77e5;&#x8bc6; (Explicit Knowledge)">
<node CREATED="1124007973795" MODIFIED="1124007973795" TEXT="&#x662f;&#x80fd;&#x7528;&#x6587;&#x5b57;&#x548c;&#x6570;&#x5b57;&#x8868;&#x8fbe;&#x51fa;&#x6765;&#xff0c;&#x5bb9;&#x6613;&#x4ee5;&#x786c;&#x6570;&#x636e;&#x7684;&#x5f62;&#x5f0f;&#x4ea4;&#x6d41;&#x548c;&#x5171;&#x4eab;&#xff0c;&#x6bd4;&#x5982;&#x7f16;&#x8f91;&#x6574;&#x7406;&#x7684;&#x7a0b;&#x5e8f;&#x6216;&#x8005;&#x666e;&#x904d;&#x539f;&#x5219;&#x3002;"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124007973795" FOLDED="true" ID="Freemind_Link_1990515644" MODIFIED="1128865841715" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7684;&#x8f6c;&#x6362;">
<node CREATED="1128865911215" ID="Freemind_Link_314238714" LINK="http://yyq123.journalspace.com/?entryid=35" MODIFIED="1128865911215" TEXT="&#x9690;&#x6027;&#x77e5;&#x8bc6;&#x4e0e;&#x663e;&#x6027;&#x77e5;&#x8bc6;&#x7684;&#x76f8;&#x4e92;&#x8f6c;&#x6362;"/>
<node CREATED="1128865911231" LINK="http://www.amteam.org/static/57104.html" MODIFIED="1128865911231" TEXT="&#x4e2a;&#x4eba;&#x77e5;&#x8bc6;&#x4e0e;&#x7ec4;&#x7ec7;&#x77e5;&#x8bc6;&#x7684;&#x76f8;&#x4e92;&#x8f6c;&#x6362;"/>
</node>
<node COLOR="#006699" CREATED="1124007973795" FOLDED="true" ID="Freemind_Link_666871784" MODIFIED="1128865842559" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x5728;&#x54ea;&#x91cc;">
<node CREATED="1124007973795" MODIFIED="1124007973795" TEXT="&lt;html&gt;&lt;img src=&quot;km_know_elem.png&quot;&gt;"/>
<node CREATED="1128931915140" FOLDED="true" ID="_" MODIFIED="1128931928547" TEXT="&#x4f01;&#x4e1a;&#x4e2d;&#x4e3b;&#x8981;&#x5b58;&#x5728;&#x4ee5;&#x4e0b;&#x51e0;&#x7c7b;&#x77e5;&#x8bc6;">
<node CREATED="1128931944172" MODIFIED="1128931944172" TEXT="&#x4e1a;&#x52a1;&#x77e5;&#x8bc6;&#xff1a;&#x7531;ERP&#x7b49;&#x4e1a;&#x52a1;&#x7cfb;&#x7edf;&#x6240;&#x751f;&#x6210;&#x548c;&#x7ba1;&#x7406;&#x3002;"/>
<node CREATED="1128931944172" MODIFIED="1128931944172" TEXT="&#x5458;&#x5de5;&#x77e5;&#x8bc6;&#xff1a;&#x5458;&#x5de5;&#x4e2a;&#x4eba;&#x6280;&#x80fd;&#x3001;&#x77e5;&#x8bc6;&#x6f5c;&#x529b;&#x3001;&#x5de5;&#x4f5c;&#x7ecf;&#x9a8c;&#x3001;&#x5de5;&#x4f5c;&#x8bb0;&#x5f55;&#x3002;"/>
<node CREATED="1128931944172" MODIFIED="1128931944172" TEXT="&#x6d41;&#x7a0b;&#x77e5;&#x8bc6;&#xff1a;&#x5c06;&#x77e5;&#x8bc6;&#x5d4c;&#x5165;&#x4e1a;&#x52a1;&#x6d41;&#x7a0b;&#x4e4b;&#x4e2d;&#xff0c;&#x5728;&#x5173;&#x952e;&#x73af;&#x8282;&#x80fd;&#x6709;&#x4e13;&#x5bb6;&#x77e5;&#x8bc6;&#x652f;&#x6301;&#x3002;"/>
<node CREATED="1128931944172" MODIFIED="1128931944172" TEXT="&#x7ec4;&#x7ec7;&#x8bb0;&#x5fc6;&#xff1a;&#x8bb0;&#x5f55;&#x73b0;&#x6709;&#x7ecf;&#x9a8c;&#x4ee5;&#x5907;&#x5c06;&#x6765;&#x4e4b;&#x7528;&#x3002;&#x5305;&#x62ec;&#x77e5;&#x8bc6;&#x5e93;&#x3001;&#x6848;&#x4f8b;&#x5e93;&#x3001;&#x6700;&#x4f73;&#x5b9e;&#x8df5;&#x5e93;&#x548c;&#x5386;&#x53f2;&#x6863;&#x6848;&#x7b49;&#x3002;"/>
<node CREATED="1128931944187" MODIFIED="1128931944187" TEXT="&#x5ba2;&#x6237;&#x77e5;&#x8bc6;&#xff1a;&#x901a;&#x8fc7;&#x5ba2;&#x6237;&#x5173;&#x7cfb;&#x53d1;&#x5c55;&#x6df1;&#x5c42;&#x77e5;&#x8bc6;&#xff0c;&#x63d0;&#x9ad8;&#x4ea7;&#x54c1;&#x548c;&#x670d;&#x52a1;&#x8d28;&#x91cf;&#xff0c;&#x4ee5;&#x6b64;&#x8d62;&#x5f97;&#x66f4;&#x591a;&#x5ba2;&#x6237;&#x3002;"/>
<node CREATED="1128931944187" MODIFIED="1128931944187" TEXT="&#x4ea7;&#x54c1;&#x548c;&#x670d;&#x52a1;&#x77e5;&#x8bc6;&#xff1a;&#x4ea7;&#x54c1;&#x4e2d;&#x8981;&#x6709;&#x77e5;&#x8bc6;&#x542b;&#x91cf;&#xff0c;&#x56f4;&#x7ed5;&#x4ea7;&#x54c1;&#x63d0;&#x4f9b;&#x77e5;&#x8bc6;&#x5bc6;&#x96c6;&#x670d;&#x52a1;&#x3002;"/>
<node CREATED="1128931944187" MODIFIED="1128931944187" TEXT="&#x5173;&#x7cfb;&#x77e5;&#x8bc6;&#xff1a;&#x63d0;&#x9ad8;&#x8de8;&#x9886;&#x57df;&#x7684;&#x77e5;&#x8bc6;&#x6d41;&#x52a8;&#xff0c;&#x6bd4;&#x5982;&#x5229;&#x7528;&#x4e0e;&#x4f9b;&#x5e94;&#x5546;&#x3001;&#x5ba2;&#x6237;&#x4ee5;&#x53ca;&#x96c7;&#x5458;&#x7684;&#x5173;&#x7cfb;&#x7b49;&#x3002;"/>
<node CREATED="1128931944187" MODIFIED="1128931944187" TEXT="&#x77e5;&#x8bc6;&#x8d44;&#x4ea7;&#xff1a;&#x667a;&#x6167;&#x578b;&#x8d44;&#x672c;/&#x4e13;&#x5229;&#x548c;&#x65e0;&#x5f62;&#x77e5;&#x8bc6;&#x4ea7;&#x6743;&#xff0c;&#x63a7;&#x5236;&#x5176;&#x53d1;&#x5c55;&#x548c;&#x5229;&#x7528;&#x3002;"/>
<node CREATED="1128931944187" MODIFIED="1128931944187" TEXT="&#x5916;&#x90e8;&#x60c5;&#x62a5;&#xff1a;&#x4ece;Internet&#x3001;&#x5916;&#x90e8;&#x4e13;&#x5bb6;&#x7b49;&#x6e20;&#x9053;&#x4ece;&#x4f01;&#x4e1a;&#x5916;&#x90e8;&#x6536;&#x96c6;&#x5230;&#x7684;&#x77e5;&#x8bc6;&#x548c;&#x60c5;&#x62a5;&#x3002;"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124007973795" ID="Freemind_Link_1625254965" MODIFIED="1128865843262" POSITION="right" TEXT="&#x4ec0;&#x4e48;&#x662f;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;">
<node COLOR="#996600" CREATED="1124007973795" ID="Freemind_Link_822066723" MODIFIED="1129000488128" TEXT="APCQ&#xff08;&#x7f8e;&#x56fd;&#x751f;&#x4ea7;&#x529b;&#x548c;&#x8d28;&#x91cf;&#x4e2d;&#x5fc3;&#xff09;&#x5bf9;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x5b9a;&#x4e49;&#x662f;&#xff1a;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x5e94;&#x8be5;&#x662f;&#x7ec4;&#x7ec7;&#x4e00;&#x79cd;&#x6709;&#x610f;&#x8bc6;&#x91c7;&#x53d6;&#x7684;&#x6218;&#x7565;&#xff0c;&#x5b83;&#x4fdd;&#x8bc1;&#x80fd;&#x591f;&#x5728;&#x6700;&#x9700;&#x8981;&#x7684;&#x65f6;&#x95f4;&#x5c06;&#x6700;&#x9700;&#x8981;&#x7684;&#x77e5;&#x8bc6;&#x4f20;&#x9001;&#x7ed9;&#x6700;&#x9700;&#x8981;&#x7684;&#x4eba;&#x3002;&#x8fd9;&#x6837;&#x53ef;&#x4ee5;&#x5e2e;&#x52a9;&#x4eba;&#x4eec;&#x5171;&#x4eab;&#x4fe1;&#x606f;&#xff0c;&#x5e76;&#x8fdb;&#x800c;&#x5c06;&#x4e4b;&#x901a;&#x8fc7;&#x4e0d;&#x540c;&#x7684;&#x65b9;&#x5f0f;&#x4ed8;&#x8bf8;&#x5b9e;&#x8df5;&#xff0c;&#x6700;&#x7ec8;&#x8fbe;&#x5230;&#x63d0;&#x9ad8;&#x7ec4;&#x7ec7;&#x4e1a;&#x7ee9;&#x7684;&#x76ee;&#x7684;&#x3002;"/>
<node COLOR="#996600" CREATED="1124007973795" ID="Freemind_Link_1964081385" MODIFIED="1129000489347" TEXT="&#x65af;&#x5a01;&#x6bd4;&#xff08;Karl E. Sveiby&#xff09;&#x4ece;&#x8ba4;&#x8bc6;&#x8bba;&#x7684;&#x89d2;&#x5ea6;&#x5bf9;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x5b9a;&#x4e49;&#x662f;&#xff1a;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x662f;&#x5229;&#x7528;&#x7ec4;&#x7ec7;&#x7684;&#x65e0;&#x5f62;&#x8d44;&#x4ea7;&#x521b;&#x9020;&#x4ef7;&#x503c;&#x7684;&#x827a;&#x672f;&#x3002;"/>
</node>
<node COLOR="#006699" CREATED="1124007973795" FOLDED="true" ID="Freemind_Link_259886815" MODIFIED="1128865843965" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x8d77;&#x6e90;">
<node CREATED="1124007973795" MODIFIED="1124007973795" TEXT="&#x65af;&#x5a01;&#x6bd4;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x65af;&#x5a01;&#x6bd4;&#xff0c;&#x4e8e;1986&#x5e74;&#x7528;&#x745e;&#x5178;&#x6587;&#x51fa;&#x7248;&#x4e86;&#x300a;&#x77e5;&#x8bc6;&#x578b;&#x4f01;&#x4e1a;&#x300b;&#xff0c;&#x4f7f;&#x4ed6;&#x6210;&#x4e3a;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7406;&#x8bba;&#x4e0e;&#x5b9e;&#x8df5;&#x7684;&#x201c;&#x745e;&#x5178;&#x8fd0;&#x52a8;&#x201d;&#x7684;&#x601d;&#x60f3;&#x6e90;&#x6cc9;&#x3002;1987&#x5e74;&#xff0c;&#x4ed6;&#x548c;&#x82f1;&#x56fd;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x4e13;&#x5bb6;&#x6c64;&#x59c6;&#xb7;&#x52b3;&#x57c3;&#x5fb7;&#x5408;&#x8457;&#x51fa;&#x7248;&#x4e86;&#x300a;&#x77e5;&#x8bc6;&#x578b;&#x4f01;&#x4e1a;&#x7684;&#x7ba1;&#x7406;&#x300b;&#x4e00;&#x4e66;&#xff0c;&#x63d0;&#x51fa;&#x4e00;&#x6574;&#x5957;&#x77e5;&#x8bc6;&#x578b;&#x4f01;&#x4e1a;&#x7ba1;&#x7406;&#x7406;&#x8bba;&#x548c;&#x5b9e;&#x7528;&#x65b9;&#x6cd5;&#xff0c;&#x6210;&#x4e3a;&#x77e5;&#x8bc6;&#x578b;&#x4f01;&#x4e1a;&#x7ba1;&#x7406;&#x7684;&#x5f00;&#x5c71;&#x4e4b;&#x4f5c;&#x3002;1990&#x5e74;&#xff0c;&#x65af;&#x5a01;&#x6bd4;&#x51fa;&#x7248;&#x4e86;&#x300a;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x300b;&#x4e00;&#x4e66;&#xff0c;&#x662f;&#x4e16;&#x754c;&#x4e0a;&#x7b2c;&#x4e00;&#x90e8;&#x4ee5;&#x201c;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x201d;&#x4e3a;&#x9898;&#x7684;&#x8457;&#x4f5c;&#x3002;"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_1041335599" MODIFIED="1128865844668" POSITION="right" TEXT="&#x4e3a;&#x4ec0;&#x4e48;&#x9700;&#x8981;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x77e5;&#x8bc6;&#x6210;&#x4e3a;&#x6700;&#x4e3b;&#x8981;&#x7684;&#x8d22;&#x5bcc;&#x6765;&#x6e90;">
<icon BUILTIN="bookmark"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5f62;&#x6210;&#x7ade;&#x4e89;&#x4f18;&#x52bf;&#x9700;&#x8981;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;">
<icon BUILTIN="bookmark"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4f01;&#x4e1a;&#x7684;&#x53ef;&#x6301;&#x7eed;&#x53d1;&#x5c55;&#x9700;&#x8981;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;">
<icon BUILTIN="bookmark"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4f18;&#x5316;&#x4f01;&#x4e1a;&#x7ecf;&#x8425;&#x9700;&#x8981;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;">
<icon BUILTIN="bookmark"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x4fe1;&#x606f;&#x6280;&#x672f;&#x7684;&#x53d1;&#x5c55;&#x50ac;&#x751f;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;">
<icon BUILTIN="bookmark"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_1215144680" MODIFIED="1128865845403" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x6784;&#x6210;&#x5143;&#x7d20;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&lt;html&gt;&lt;img src=&quot;km_inscape.png&quot;&gt;"/>
</node>
<node COLOR="#006699" CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_222680323" MODIFIED="1128865846106" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x67b6;&#x6784;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&lt;html&gt;&lt;img src=&quot;km_syst_stru.png&quot;&gt;"/>
</node>
<node COLOR="#006699" CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_388934713" MODIFIED="1128865846653" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x6218;&#x7565;">
<node CREATED="1128932000750" FOLDED="true" ID="Freemind_Link_727487565" MODIFIED="1128932003640" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x6218;&#x7565;&#x5fc5;&#x987b;&#x652f;&#x6301;&#x7ecf;&#x8425;&#x6218;&#x7565;&#xff0c;&#x5e76;&#x4e14;&#x8d85;&#x8d8a;&#x7ecf;&#x8425;&#x6218;&#x7565;&#x3002;--CKO Summit 2000">
<node CREATED="1128932019500" ID="Freemind_Link_1803437432" MODIFIED="1128932041093" TEXT="&lt;html&gt;&lt;img src=&quot;km_strategy.png&quot;&gt;"/>
</node>
<node CREATED="1128932052422" ID="Freemind_Link_962980873" MODIFIED="1128932054375" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x6218;&#x7565;&#x6a21;&#x5f0f;">
<node CREATED="1124007973811" ID="Freemind_Link_32394462" MODIFIED="1128932074750" TEXT="&#x628a;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x4f5c;&#x4e3a;&#x7ec4;&#x7ec7;&#x7ecf;&#x8425;&#x6218;&#x7565;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1590619162" MODIFIED="1128932089281" TEXT="&#x77e5;&#x8bc6;&#x8f6c;&#x79fb;&#x548c;&#x6700;&#x4f18;&#x5b9e;&#x8df5;&#x6d3b;&#x52a8;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1331386374" MODIFIED="1128932104359" TEXT="&#x4ee5;&#x5ba2;&#x6237;&#x4e3a;&#x91cd;&#x70b9;&#x7684;&#x77e5;&#x8bc6;&#x6218;&#x7565;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1437850382" MODIFIED="1128932107734" TEXT="&#x5efa;&#x7acb;&#x7ec4;&#x7ec7;&#x6210;&#x5458;&#x5bf9;&#x77e5;&#x8bc6;&#x7684;&#x8d23;&#x4efb;&#x611f;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1806927255" MODIFIED="1128932111656" TEXT="&#x65e0;&#x5f62;&#x8d44;&#x4ea7;&#x7ba1;&#x7406;&#x6218;&#x7565;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_69919944" MODIFIED="1128932114234" TEXT="&#x6280;&#x672f;&#x521b;&#x65b0;&#x548c;&#x77e5;&#x8bc6;&#x521b;&#x9020;&#x6218;&#x7565;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x8d44;&#x6599;&#x6765;&#x6e90;&#xff1a;&#x7f8e;&#x56fd;&#x751f;&#x4ea7;&#x529b;&#x4e0e;&#x8d28;&#x91cf;&#x7814;&#x7a76;&#x4e2d;&#x5fc3;"/>
</node>
</node>
</node>
</map>
