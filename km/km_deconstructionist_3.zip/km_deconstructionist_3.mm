<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#3366ff" CREATED="1124007973795" ID="Freemind_Link_1278772365" LINK="http://yyq123.journalspace.com/?entryid=117" MODIFIED="1129729706937" TEXT="KM &#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#xff08;&#x4e0b;&#xff09;">
<font BOLD="true" NAME="SansSerif" SIZE="18"/>
<node COLOR="#006699" CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_1681798468" MODIFIED="1129727892765" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x5b9e;&#x65bd;&#x6b65;&#x9aa4;">
<node COLOR="#ff0000" CREATED="1124007973811" ID="Freemind_Link_849594105" MODIFIED="1124007973811" TEXT="&lt;html&gt;&lt;img src=&quot;km_impl_step.png&quot;&gt;"/>
</node>
<node COLOR="#006699" CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_1868562776" MODIFIED="1129727893437" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x5b9e;&#x65bd;&#x7684;&#x65b9;&#x6cd5;">
<node CREATED="1124007973811" ID="Freemind_Link_731189703" MODIFIED="1129729404203" TEXT="&#x6784;&#x5efa;&#x652f;&#x6301;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x7ec4;&#x7ec7;&#x4f53;&#x7cfb;">
<icon BUILTIN="password"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1121713654" MODIFIED="1129729404203" TEXT="&#x52a0;&#x5927;&#x5bf9;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x8d44;&#x91d1;&#x6295;&#x5165;">
<icon BUILTIN="password"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1127694619" MODIFIED="1129729404203" TEXT="&#x521b;&#x9020;&#x6709;&#x5229;&#x4e8e;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x7ec4;&#x7ec7;&#x6587;&#x5316;">
<icon BUILTIN="password"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_489334365" MODIFIED="1129729404187" TEXT="&#x5236;&#x5b9a;&#x9f13;&#x52b1;&#x77e5;&#x8bc6;&#x521b;&#x9020;&#x548c;&#x8f6c;&#x79fb;&#x7684;&#x6fc0;&#x52b1;&#x63aa;&#x65bd;">
<icon BUILTIN="password"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1657581204" MODIFIED="1129729404171" TEXT="&#x5f00;&#x53d1;&#x652f;&#x6491;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x4fe1;&#x606f;&#x6280;&#x672f;">
<icon BUILTIN="password"/>
</node>
<node CREATED="1124007973811" ID="Freemind_Link_1623355755" MODIFIED="1129729404187" TEXT="&#x5efa;&#x7acb;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x8bc4;&#x4f30;&#x7cfb;&#x7edf;">
<icon BUILTIN="password"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x8d44;&#x6599;&#x6765;&#x6e90;&#xff1a;&#x7f8e;&#x56fd;&#x751f;&#x4ea7;&#x529b;&#x4e0e;&#x8d28;&#x91cf;&#x7814;&#x7a76;&#x4e2d;&#x5fc3;"/>
</node>
<node COLOR="#006699" CREATED="1124007973811" FOLDED="true" ID="Freemind_Link_1761081211" MODIFIED="1129727894281" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x6210;&#x529f;&#x5173;&#x952e;">
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x4e0e;&#x4f01;&#x4e1a;&#x7ecf;&#x8425;&#x6218;&#x7565;&#x7684;&#x7ed3;&#x5408;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x9ad8;&#x5c42;&#x9886;&#x5bfc;&#x7684;&#x5168;&#x529b;&#x652f;&#x6301;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x5168;&#x90e8;&#x5458;&#x5de5;&#x7684;&#x79ef;&#x6781;&#x53c2;&#x4e0e;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x91cd;&#x89c6;&#x77e5;&#x8bc6;&#x5171;&#x4eab;&#x7684;&#x4f01;&#x4e1a;&#x6587;&#x5316;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x9f13;&#x52b1;&#x77e5;&#x8bc6;&#x5171;&#x4eab;&#x7684;&#x6fc0;&#x52b1;&#x5236;&#x5ea6;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973811" MODIFIED="1124007973811" TEXT="&#x6241;&#x5e73;&#x5316;&#x67d4;&#x6027;&#x5316;&#x7684;&#x7ec4;&#x7ec7;&#x67b6;&#x6784;">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x6613;&#x4e8e;&#x4f7f;&#x7528;&#x7684;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x8f6f;&#x4ef6;">
<icon BUILTIN="idea"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_116428478" MODIFIED="1129727895062" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x5931;&#x8d25;&#x539f;&#x56e0;">
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x4e03;&#x4e2a;&#x8ba4;&#x8bc6;&#x8bef;&#x533a;">
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_1502197290" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x662f;&#x5173;&#x4e8e;&#x77e5;&#x8bc6;&#x7684;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7cfb;&#x7edf;&#x5e94;&#x8be5;&#x628a;&#x5173;&#x6ce8;&#x7684;&#x7126;&#x70b9;&#x653e;&#x5728;&#x5feb;&#x901f;&#x589e;&#x957f;&#x3001;&#x6539;&#x5584;&#x8fd0;&#x8425;&#x548c;&#x589e;&#x52a0;&#x5229;&#x6da6;&#x7a7a;&#x95f4;&#x4e0a;&#x3002; "/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_1226604493" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x662f;&#x5173;&#x4e8e;&#x6280;&#x672f;&#x7684;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x4e0d;&#x662f;&#x4e00;&#x4e2a;&#x5355;&#x7eaf;&#x6280;&#x672f;&#x9879;&#x76ee;&#xff0c;&#x5b83;&#x5fc5;&#x987b;&#x80fd;&#x591f;&#x9002;&#x5e94;&#x5feb;&#x901f;&#x53d8;&#x5316;&#x7684;&#x5546;&#x4e1a;&#x73af;&#x5883;&#x3002;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_476528142" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x662f;&#x4e07;&#x80fd;&#x7684;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x4e0d;&#x53ef;&#x80fd;&#x4e00;&#x5929;&#x5c31;&#x89e3;&#x51b3;&#x6240;&#x6709;&#x7684;&#x4fe1;&#x606f;&#x95ee;&#x9898;&#xff0c;&#x5e94;&#x8be5;&#x4ece;&#x5c0f;&#x5904;&#x5f00;&#x59cb;&#x9010;&#x6b65;&#x53d6;&#x5f97;&#x6210;&#x6548;&#x3002;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_1755483850" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x76ee;&#x6807;&#x662f;&#x5efa;&#x7acb;&#x4e00;&#x4e2a;&#x6587;&#x6863;&#x5e93;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x4e0d;&#x4ec5;&#x4ec5;&#x662f;&#x4e3a;&#x4e86;&#x4fdd;&#x5b58;&#x4fe1;&#x606f;&#xff0c;&#x66f4;&#x91cd;&#x8981;&#x7684;&#x662f;&#x8981;&#x5229;&#x7528;&#x77e5;&#x8bc6;&#x5e2e;&#x52a9;&#x4f01;&#x4e1a;&#x505a;&#x51fa;&#x66f4;&#x597d;&#x7684;&#x51b3;&#x7b56;&#x3002;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_1004457193" MODIFIED="1124007973827" TEXT="&#x80fd;&#x4e70;&#x5230;&#x4e00;&#x4e2a;&#x73b0;&#x6210;&#x7684;&#x7cfb;&#x7edf;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x5de5;&#x5177;&#x7e41;&#x591a;&#xff0c;&#x6838;&#x5fc3;&#x95ee;&#x9898;&#x662f;&#x600e;&#x6837;&#x628a;&#x8fd9;&#x4e9b;&#x5de5;&#x5177;&#x548c;&#x4f60;&#x7684;&#x6210;&#x957f;&#xff0c;&#x8fd0;&#x8425;&#x548c;&#x6280;&#x672f;&#x6218;&#x7565;&#x8fdb;&#x884c;&#x96c6;&#x6210;&#x3002;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_742416767" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x5c31;&#x662f;&#x63a7;&#x5236;&#x77e5;&#x8bc6;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x4e0d;&#x662f;&#x4e3a;&#x4e86;&#x63a7;&#x5236;&#x77e5;&#x8bc6;&#xff0c;&#x800c;&#x662f;&#x8981;&#x52aa;&#x529b;&#x57f9;&#x80b2;&#x4e00;&#x79cd;&#x5206;&#x4eab;&#x77e5;&#x8bc6;&#x7684;&#x4f01;&#x4e1a;&#x6587;&#x5316;&#x3002;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_303091181" MODIFIED="1124007973827" TEXT="&#x505a;&#x597d;&#x4e4b;&#x540e;&#xff0c;&#x4ed6;&#x4eec;&#x5c31;&#x4f1a;&#x7528;&#x7684;">
<icon BUILTIN="clanbomber"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x6210;&#x529f;&#x5e94;&#x7528;&#xff0c;&#x5fc5;&#x987b;&#x5f97;&#x5230;&#x9ad8;&#x5c42;&#x9886;&#x5bfc;&#x7684;&#x575a;&#x5b9a;&#x652f;&#x6301;&#x5e76;&#x914d;&#x5408;&#x9f13;&#x52b1;&#x77e5;&#x8bc6;&#x5171;&#x4eab;&#x7684;&#x4f01;&#x4e1a;&#x5236;&#x5ea6;&#x3002;"/>
</node>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x5341;&#x79cd;&#x5931;&#x8d25;&#x56e0;&#x7d20;">
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x6ca1;&#x6709;&#x83b7;&#x5f97;&#x9ad8;&#x5c42;&#x9886;&#x5bfc;&#x7684;&#x652f;&#x6301;">
<icon BUILTIN="clanbomber"/>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x7531;&#x4e0a;&#x800c;&#x4e0b;&#x8fdb;&#x884c;&#x7684;&#x9879;&#x76ee;&#xff0c;&#x6ca1;&#x6709;&#x5e95;&#x5c42;&#x7684;&#x53c2;&#x4e0e;">
<icon BUILTIN="clanbomber"/>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x5ffd;&#x7565;&#x5728;&#x4eba;&#x4e8b;&#x548c;&#x6280;&#x672f;&#x4e0a;&#x7684;&#x540e;&#x7eed;&#x652f;&#x51fa;">
<icon BUILTIN="clanbomber"/>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x9009;&#x62e9;&#x9519;&#x8bef;&#x7684;&#x6280;&#x672f;&#x89e3;&#x51b3;&#x65b9;&#x6848;">
<icon BUILTIN="clanbomber"/>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x6ca1;&#x6709;&#x9884;&#x5148;&#x8bbe;&#x5b9a;&#x8fd0;&#x8425;&#x7684;&#x76ee;&#x6807;">
<icon BUILTIN="clanbomber"/>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x9009;&#x62e9;&#x9519;&#x8bef;&#x7684;&#x987e;&#x95ee;&#x516c;&#x53f8;">
<icon BUILTIN="clanbomber"/>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x9519;&#x8bef;&#x7684;&#x8861;&#x91cf;&#x8fc7;&#x7a0b;">
<icon BUILTIN="clanbomber"/>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x5236;&#x5b9a;&#x5bbd;&#x6cdb;&#x7684;&#x7b56;&#x7565;&#xff0c;&#x65e0;&#x6cd5;&#x5b8c;&#x5168;&#x5b9e;&#x73b0;">
<icon BUILTIN="clanbomber"/>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x5ffd;&#x7565;&#x7528;&#x6237;&#x7684;&#x56e0;&#x7d20;">
<icon BUILTIN="clanbomber"/>
</node>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x7f3a;&#x4e4f;&#x5b9e;&#x65bd;&#x540e;&#x7684;&#x6301;&#x7eed;&#x6539;&#x8fdb;">
<icon BUILTIN="clanbomber"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_789913764" MODIFIED="1129727895843" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x8bc4;&#x4f30;&#x65b9;&#x6cd5;">
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_253647090" MODIFIED="1129729505312" TEXT="&#x4eba;&#x529b;&#x8d44;&#x672c;">
<icon BUILTIN="password"/>
<node CREATED="1124007973827" ID="Freemind_Link_1004515200" MODIFIED="1124007973827" TEXT="&#x57f9;&#x8bad;&#x8d39;&#x7528;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x7ec4;&#x7ec7;&#x5b66;&#x4e60;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x5458;&#x5de5;&#x5fe0;&#x8bda;&#x5ea6;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x7ba1;&#x7406;&#x7ecf;&#x9a8c;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_1001770247" MODIFIED="1129729505312" TEXT="&#x521b;&#x65b0;&#x8d44;&#x672c;">
<icon BUILTIN="password"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x7814;&#x53d1;&#x8d39;&#x7528;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x4ece;&#x4e8b;&#x521b;&#x65b0;&#x7684;&#x5458;&#x5de5;&#x6bd4;&#x7387;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x4ea7;&#x54c1;&#x66f4;&#x65b0;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x4ea7;&#x6743;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_1909129606" MODIFIED="1129729505328" TEXT="&#x5ba2;&#x6237;&#x8d44;&#x672c;">
<icon BUILTIN="password"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x6ee1;&#x610f;&#x5ea6;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x670d;&#x52a1;&#x8d28;&#x91cf;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x5408;&#x4f5c;&#x7684;&#x65f6;&#x95f4;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x91cd;&#x590d;&#x8d2d;&#x4e70;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x9500;&#x552e;&#x989d;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_1471732533" MODIFIED="1129729505328" TEXT="&#x77e5;&#x8bc6;&#x8bc6;&#x522b;&#x9636;&#x6bb5;">
<icon BUILTIN="password"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x5e93;&#x4e2d;&#x8054;&#x7cfb;&#x7684;&#x6570;&#x76ee;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x5e93;&#x4e2d;&#x4e3b;&#x9898;&#x7684;&#x6570;&#x76ee;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x70b9;&#x51fb;&#x7387;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x751f;&#x4ea7;&#x529b;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_8266912" MODIFIED="1129729505328" TEXT="&#x77e5;&#x8bc6;&#x8bf1;&#x5bfc;&#x9636;&#x6bb5;">
<icon BUILTIN="password"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x6765;&#x81ea;&#x4e8e;&#x77e5;&#x8bc6;&#x5e93;&#x7684;&#x65b0;&#x9700;&#x6c42;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x53ef;&#x8fbe;&#x5230;&#x7684;&#x76f8;&#x5173;&#x8d44;&#x6e90;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_1442545884" MODIFIED="1129729505312" TEXT="&#x77e5;&#x8bc6;&#x5206;&#x53d1;&#x9636;&#x6bb5;">
<icon BUILTIN="password"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x63a8;&#x7684;&#x65b9;&#x5f0f;&#x5206;&#x53d1;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x62c9;&#x7684;&#x65b9;&#x5f0f;&#x5206;&#x53d1;"/>
</node>
<node CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_1678843662" MODIFIED="1129729505312" TEXT="&#x77e5;&#x8bc6;&#x5229;&#x7528;&#x9636;&#x6bb5;">
<icon BUILTIN="password"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x805a;&#x96c6;&#x6d3b;&#x52a8;&#x4e2d;&#x7684;&#x7cfb;&#x7edf;&#x5229;&#x7528;&#x7387;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x7528;&#x6237;&#x6ee1;&#x610f;&#x5ea6;"/>
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&#x77e5;&#x8bc6;&#x5229;&#x7528;&#x8fc7;&#x7a0b;&#x4e2d;&#x4ea7;&#x751f;&#x7684;&#x5546;&#x4e1a;&#x673a;&#x4f1a;"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124007973827" ID="Freemind_Link_1364903926" MODIFIED="1129727896656" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x4e3b;&#x8981;&#x6536;&#x76ca;">
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&lt;html&gt;&lt;img src=&quot;km_benefit.png&quot;&gt;"/>
</node>
<node COLOR="#006699" CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_144880548" MODIFIED="1129727897468" POSITION="right" TEXT="&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x6700;&#x4f73;&#x5b9e;&#x8df5;">
<node CREATED="1124007973827" ID="Freemind_Link_664136537" LINK="http://yyq123.journalspace.com/?entryid=31" MODIFIED="1129729529781" TEXT="&#x65bd;&#x4e50;&#x516c;&#x53f8;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x6574;&#x4f53;&#x89e3;&#x51b3;&#x65b9;&#x6848;"/>
<node CREATED="1124007973827" ID="Freemind_Link_1279751932" LINK="http://yyq123.journalspace.com/?entryid=32" MODIFIED="1129729541421" TEXT="&#x82f1;&#x56fd;&#x77f3;&#x6cb9;&#x516c;&#x53f8;&#x6210;&#x529f;&#x5b9e;&#x65bd;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x7684;&#x7ecf;&#x9a8c; "/>
<node CREATED="1124007973827" ID="Freemind_Link_1627190088" LINK="http://yyq123.journalspace.com/?entryid=30" MODIFIED="1129729552625" TEXT="&#x6469;&#x6258;&#x7f57;&#x62c9;&#x7684;&#x77e5;&#x8bc6;&#x7ba1;&#x7406; "/>
</node>
<node COLOR="#006699" CREATED="1124007973827" FOLDED="true" ID="Freemind_Link_203704327" MODIFIED="1129727898859" POSITION="right" TEXT="&#x7ed3;&#x8bed;">
<node CREATED="1124007973827" MODIFIED="1124007973827" TEXT="&lt;html&gt;&lt;img src=&quot;km_market_analyse.png&quot;&gt;"/>
<node CREATED="1129729595593" ID="Freemind_Link_151759344" MODIFIED="1129729599937" TEXT="Market competition becomes competition on knowledge!">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124007973827" ID="Freemind_Link_1665726054" MODIFIED="1129729612796" TEXT="&#x7ba1;&#x7406;&#x5927;&#x5e08;&#x5f7c;&#x5f97;&#xb7;&#x675c;&#x62c9;&#x514b;&#x5728;1993&#x5e74;&#x6240;&#x5199;&#x7684;&#x300a;&#x540e;&#x8d44;&#x672c;&#x4e3b;&#x4e49;&#x793e;&#x4f1a;&#x300b;&#x4e2d;&#x8868;&#x793a;&#xff1a;&#x201c;&#x6211;&#x4eec;&#x6b63;&#x8fdb;&#x5165;&#x4e00;&#x4e2a;&#x77e5;&#x8bc6;&#x793e;&#x4f1a;&#xff0c;&#x5728;&#x8fd9;&#x4e2a;&#x793e;&#x4f1a;&#x5f53;&#x4e2d;&#xff0c;&#x57fa;&#x672c;&#x7684;&#x7ecf;&#x6d4e;&#x8d44;&#x6e90;&#x5c06;&#x4e0d;&#x518d;&#x662f;&#x8d44;&#x672c;&#xff08;Capital&#xff09;&#x3001;&#x81ea;&#x7136;&#x8d44;&#x6e90;&#xff08;Natural Resources&#xff09;&#x6216;&#x52b3;&#x529b;&#xff08;Labor&#xff09;&#xff0c;&#x800c;&#x5c06;&#x662f;&#x77e5;&#x8bc6;&#xff08;Knowledge&#xff09;&#xff1b;&#x77e5;&#x8bc6;&#x5458;&#x5de5;&#x5c06;&#x6210;&#x4e3a;&#x5176;&#x4e2d;&#x7684;&#x4e3b;&#x89d2;&#x3002;&#x201d;&#x5982;&#x4f55;&#x7ba1;&#x7406;&#x597d;&#x77e5;&#x8bc6;&#xff1f;&#x662f;&#x73b0;&#x4ee3;&#x4f01;&#x4e1a;&#x5fc5;&#x987b;&#x9762;&#x5bf9;&#x7684;&#x6311;&#x6218;&#xff01;"/>
<node CREATED="1129729628796" MODIFIED="1129729628796" TEXT="&#x968f;&#x7740;&#x8fd1;&#x5e74;&#x6765;&#xff0c;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x5e02;&#x573a;&#x7684;&#x9010;&#x6b65;&#x6269;&#x5927;&#x548c;&#x4f01;&#x4e1a;&#x5bf9;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x91cd;&#x89c6;&#x7a0b;&#x5ea6;&#x7684;&#x4e0d;&#x65ad;&#x63d0;&#x9ad8;&#xff0c;&#x77e5;&#x8bc6;&#x7ba1;&#x7406;&#x6b63;&#x5728;&#x6210;&#x4e3a;&#x4f01;&#x4e1a;&#x4fe1;&#x606f;&#x5316;&#x7684;&#x70ed;&#x70b9;&#x3002;&#x6211;&#x575a;&#x4fe1;&#xff0c;&#x5728;&#x4e0d;&#x8fdc;&#x7684;&#x5c06;&#x6765;&#xff0c;KM&#x5c06;&#x50cf;ERP&#x90a3;&#x6837;&#x6210;&#x4e3a;&#x4f01;&#x4e1a;&#x751f;&#x5b58;&#x548c;&#x53d1;&#x5c55;&#x7684;&#x5fc5;&#x5907;&#x8981;&#x7d20;&#x3002;"/>
</node>
<node COLOR="#006699" CREATED="1129729672156" FOLDED="true" ID="Freemind_Link_262593722" MODIFIED="1129729685296" POSITION="right" TEXT="&#x9644;&#x7eaa;">
<node CREATED="1130137654810" ID="Freemind_Link_708146099" LINK="http://del.icio.us/yyq123/km" MODIFIED="1130137654810" TEXT="&#x63a8;&#x8350;&#x7684;KM&#x7f51;&#x7ad9;"/>
<node CREATED="1130137654810" LINK="http://furl.net/members/yyq123/KM" MODIFIED="1130137654810" TEXT="&#x63a8;&#x8350;&#x7684;KM&#x6587;&#x7ae0;"/>
<node CREATED="1130137654810" LINK="http://yyq123.wikispaces.org/km-glossary" MODIFIED="1130137654810" TEXT="KM&#x8bcd;&#x6c47;&#x8868;"/>
<node CREATED="1130137654779" ID="Freemind_Link_793124472" MODIFIED="1130137654779" TEXT="&#x81f4;&#x8c22;">
<node CREATED="1130137654825" ID="Freemind_Link_821247495" LINK="http://blog.amteam.org/user1/20/index.html" MODIFIED="1130137654825" TEXT="jhkzz">
<node CREATED="1130137654779" MODIFIED="1130137654779" TEXT="&#x5728;&#x672c;&#x6587;&#x7684;&#x5199;&#x4f5c;&#x8fc7;&#x7a0b;&#x4e2d;&#xff0c;jhkzz&#x5411;&#x6211;&#x63d0;&#x4f9b;&#x4e86;&#x5f88;&#x591a;&#x6709;&#x4ef7;&#x503c;&#x7684;&#x8d44;&#x6599;&#xff0c;&#x5728;&#x6b64;&#x6df1;&#x8868;&#x8c22;&#x610f;&#x3002;"/>
</node>
</node>
</node>
</node>
</map>
